# JK投标助手（toubiao-assistant）

全流程投标文件（技术标）编制技能：读招标文件 → 定目录 → 写正文 → 查废标/查重 → 出排版 Word。
规则与数值对齐成熟桌面端投标工具的实现，等效边界见 `references/06-等效性说明.md`。

本目录是**可移植版**：`name` 用规范要求的 hyphen-case，可直接被任何支持 Agent Skills 的宿主加载。

## 一、装到哪个目录

| 宿主 | 用户级目录（全项目可用） | 项目级目录（仅当前项目） |
|---|---|---|
| WorkBuddy | `~/.workbuddy/skills/toubiao-assistant/` | `<项目>/.workbuddy/skills/toubiao-assistant/` |
| Claude Code | `~/.claude/skills/toubiao-assistant/` | `<项目>/.claude/skills/toubiao-assistant/` |
| Codex CLI | `~/.codex/skills/toubiao-assistant/` | `<项目>/.codex/skills/toubiao-assistant/` |

安装 = 把整个 `toubiao-assistant/` 目录拷进去，保持 `SKILL.md` 在根、`references/`、`scripts/` 同级：

```bash
# Windows (Git Bash)
cp -r toubiao-assistant ~/.claude/skills/
cp -r toubiao-assistant ~/.codex/skills/
```

改完要**重启宿主会话**（技能列表在启动时扫描）。装好后用一句话试触发：
「帮我按评分项给这份招标文件做技术标目录」——能被自动选中即成功。

## 二、依赖

```bash
python -m pip install python-docx          # 硬依赖：脚本 3/6 都要它
python -m pip install pypdf                # 可选：PDF 直接解析（否则回退本机 Word）
```

- Python ≥ 3.9，无第三方网络请求，不调用任何模型 API。
- `.doc` / `.wps` / 无文本层 PDF：需 **Windows + Microsoft Word**（走 COM 转 docx）。
  mac/Linux 上 docx/md 全流程不受影响，只是读不了旧格式。

装好先自检：

```bash
python <技能目录>/scripts/selfcheck.py
```

输出 `核心能力可用，可以开工。` 且退出码 0 才算环境就绪。

## 三、脚本调用约定

SKILL.md 里的 `python scripts/xxx.py` 是**相对技能目录**的写法。别的宿主不会自动把
当前目录切到技能目录，所以要显式带上路径（推荐绝对路径，不污染工作目录）：

```bash
python "$SKILL_DIR/scripts/tender_scan.py" 招标.md -o scan.json --report 红线.md
```

产物写到项目目录（`01-源文件/`、`02-解析/`、`03-目录/`、`04-正文/`、`05-导出/`），
不要写进技能目录。

## 四、不支持技能协议的智能体怎么用

按宿主能力分三档：

1. **纯对话（只收单条消息/单文件）**：用 `dist/投标助手-单文件版.md`——已把 SKILL.md
   与 6 份 references 合并成一份，并在末尾附 **附录 G 无脚本手算手册**（字数分摊、字数校正、
   目录校验的可填表格与算例；算例已与脚本实跑结果核对）。整份贴进系统提示或作为附件上传即可。
   脚本用不了，但流程、铁律、阈值、目录规则全在，模型能按流程产出一份合规方案。
2. **能读本地文件、有系统提示但无技能机制**：把单文件版放进系统提示，并告诉它脚本
   绝对路径（`D:/.../toubiao-assistant/scripts/`），让它自己 Bash 调用。
3. **能读 AGENTS.md 的宿主**（如 Codex）：在全局或项目 `AGENTS.md` 里加一条路由：

   ```markdown
   - 用户提到投标、标书、技术标、评分项、废标检查、标书查重时，
     先读 C:\Users\<你>\.codex\skills\toubiao-assistant\SKILL.md 并按其中流程执行。
   ```

## 五、目录结构

```
toubiao-assistant/
├── SKILL.md                 主流程（9 步）+ 6 条铁律 + 失败模式表
├── README.md                本文件（分发用，不影响加载）
├── references/              6 份规范：解析 / 目录 / 正文 / 质检 / 导出 / 等效边界
└── scripts/
    ├── selfcheck.py         环境自检
    ├── doc2md.py            docx/doc/wps/pdf/md → Markdown
    ├── tender_scan.py       红线 / ★▲ / 资格 / 时间 / 金额 / 评分表
    ├── outline_check.py     目录结构 + 评分项覆盖校验（不通过 exit 1）
    ├── word_budget.py       全文基准 → 每节目标字数 → 校正方案
    ├── bid_audit.py         废标线索 / 查重 / 元数据 / 材料清单
    └── md2docx.py           规范排版 Word（第X章编号 / 目录域 / 页眉 / 暗标）
```

`README.md` 对加载无副作用，保留便于同事阅读；嫌吵可以删。
